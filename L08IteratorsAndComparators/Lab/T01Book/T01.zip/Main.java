//package bg.softuni.Advanced.Lab.L19IteratorsAndComparators.T01Book;

public class Main {
    public static void main(String[] args) {

    }
}
